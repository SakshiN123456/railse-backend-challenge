package com.example.demo.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class CreateTaskRequest {
  private String title;
  private String assigneeId;
  private LocalDate startDate;
  public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getAssigneeId() {
	return assigneeId;
}
public void setAssigneeId(String assigneeId) {
	this.assigneeId = assigneeId;
}
public LocalDate getStartDate() {
	return startDate;
}
public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}
public LocalDate getDueDate() {
	return dueDate;
}
public void setDueDate(LocalDate dueDate) {
	this.dueDate = dueDate;
}
private LocalDate dueDate;
}
