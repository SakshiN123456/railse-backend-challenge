package com.example.demo.service;


import org.springframework.stereotype.Service;

import com.example.demo.dto.CommentDto;
import com.example.demo.dto.CreateTaskRequest;
import com.example.demo.dto.TaskDto;
import com.example.demo.model.Staff;
import com.example.demo.model.Task;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
@Service
public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();
    private final Map<String, Staff> staff = new HashMap<>();

    public TaskService() {
        Staff s = new Staff();
        s.setId("1");
        s.setName("Alice");
        staff.put(s.getId(), s);
    }

    // Create a task
    public TaskDto createTask(CreateTaskRequest r) {
        Task t = new Task();
        t.setId(UUID.randomUUID().toString());
        t.setTitle(r.getTitle());
        Staff assignee = staff.get(r.getAssigneeId());
        t.setAssignee(assignee);
        t.setStartDate(r.getStartDate());
        t.setDueDate(r.getDueDate());
        tasks.put(t.getId(), t);
        return toDto(t);
    }

    // Reassign task: cancel old, create new with new assignee, log activity
    public TaskDto reassignTask(String taskId, String newAssigneeId) {
        Task oldTask = tasks.get(taskId);
        if (oldTask == null) return null;

        oldTask.setStatus(Task.Status.CANCELLED);
        oldTask.getActivityLog().add("Task cancelled due to reassignment");

        Task newTask = new Task();
        newTask.setId(UUID.randomUUID().toString());
        newTask.setTitle(oldTask.getTitle());
        newTask.setAssignee(staff.get(newAssigneeId));
        newTask.setStartDate(oldTask.getStartDate());
        newTask.setDueDate(oldTask.getDueDate());
        newTask.setPriority(oldTask.getPriority());
        tasks.put(newTask.getId(), newTask);

        newTask.getActivityLog().add("Task reassigned from " + oldTask.getAssignee().getName());

        return toDto(newTask);
    }

    // Fetch tasks by staffId and date range, skip CANCELLED
    public List<TaskDto> fetchTasks(String staffId, LocalDate from, LocalDate to) {
        return tasks.values().stream()
                .filter(t -> t.getAssignee() != null
                        && staffId.equals(t.getAssignee().getId())
                        && !t.getStatus().equals(Task.Status.CANCELLED)
                        && (t.getStartDate() != null && !t.getStartDate().isBefore(from))
                        && (t.getDueDate() != null && !t.getDueDate().isAfter(to)))
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Change priority and log
    public TaskDto changePriority(String taskId, Task.Priority p) {
        Task t = tasks.get(taskId);
        if (t == null) return null;

        t.setPriority(p);
        t.getActivityLog().add("Priority changed to " + p.name());
        return toDto(t);
    }

    // Filter tasks by priority
    public List<TaskDto> tasksByPriority(Task.Priority p) {
        return tasks.values().stream()
                .filter(t -> t.getPriority() == p && t.getStatus() != Task.Status.CANCELLED)
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Add comment and log
    public CommentDto addComment(String taskId, String author, String text) {
        Task t = tasks.get(taskId);
        if (t == null) return null;

        CommentDto c = new CommentDto();
        c.setAuthor(author);
        c.setText(text);
        c.setTimestamp(java.time.Instant.now());

        // You can create a Comment model class to add to Task.comments list
        // For simplicity, just add a log entry here
        t.getActivityLog().add(author + " commented: " + text);

        // Ideally, add Comment object to Task.comments if you want full comments support
        return c;
    }

    // Get task details
    public TaskDto getTaskDetail(String taskId) {
        Task t = tasks.get(taskId);
        if (t == null) return null;
        return toDto(t);
    }

    // Mapper from Task -> TaskDto
    private TaskDto toDto(Task task) {
        TaskDto dto = new TaskDto();
        dto.setId(task.getId());
        dto.setTitle(task.getTitle());
        dto.setAssigneeId(task.getAssignee() != null ? task.getAssignee().getId() : null);
        dto.setStatus(TaskDto.Status.valueOf(task.getStatus().name()));
        dto.setPriority(TaskDto.Priority.valueOf(task.getPriority().name()));
        dto.setStartDate(task.getStartDate());
        dto.setDueDate(task.getDueDate());
        // For comments, you can map Task.comments to CommentDto list here if implemented
        dto.setComments(Collections.emptyList());
        dto.setActivityLog(task.getActivityLog());
        return dto;
    }
}


