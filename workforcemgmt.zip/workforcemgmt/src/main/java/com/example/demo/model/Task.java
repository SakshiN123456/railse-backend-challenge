package com.example.demo.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor
public class Task {
  public enum Status { ACTIVE, COMPLETED, CANCELLED }
  public enum Priority { HIGH, MEDIUM, LOW }

  private String id;
  private String title;
  public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public Staff getAssignee() {
	return assignee;
}
public void setAssignee(Staff assignee) {
	this.assignee = assignee;
}
public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}
public LocalDate getStartDate() {
	return startDate;
}
public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}
public LocalDate getDueDate() {
	return dueDate;
}
public void setDueDate(LocalDate dueDate) {
	this.dueDate = dueDate;
}
public Priority getPriority() {
	return priority;
}
public void setPriority(Priority priority) {
	this.priority = priority;
}
public List<Comment> getComments() {
	return comments;
}
public void setComments(List<Comment> comments) {
	this.comments = comments;
}
public List<String> getActivityLog() {
	return activityLog;
}
public void setActivityLog(List<String> activityLog) {
	this.activityLog = activityLog;
}
private Staff assignee;
  private Status status = Status.ACTIVE;
  private LocalDate startDate;
  private LocalDate dueDate;
  private Priority priority = Priority.MEDIUM;
  private List<Comment> comments = new ArrayList<>();
  private List<String> activityLog = new ArrayList<>();
}
